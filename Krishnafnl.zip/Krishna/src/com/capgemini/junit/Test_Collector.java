package com.capgemini.junit;

import static org.junit.Assert.*;

//import org.junit.Test;
import org.junit.*;

import com.capgemini.bin.*;
import com.capgemini.collection.*;
import com.capgemini.exception.*;
import com.capgemini.validator.*;

public class Test_Collector {

	Collector val=new Collector();
	
	@Test
	public void testID() throws ItemException1 {

		Assert.assertEquals("fail", 0,val.count_records());
		
	}
}
