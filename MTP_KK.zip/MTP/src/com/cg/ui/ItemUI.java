package com.cg.ui;

import com.capgemini.bin.*;
import java.util.*;
import com.capgemini.exception.*;
import com.capgemini.collection.*;
import com.capgemini.validator.*;


import static java.lang.System.out;
public class ItemUI {
	static Scanner cin=new Scanner(System.in);
	public static void main(String[] args) throws ItemException{
		// TODO Auto-generated method stub
       int choice;

  while(true)
{
	out.println("Enter your choice");
	out.println("1----Add Details");
	out.println("2----Display Details");
	out.println("3---- Count Of Records");
	out.println("4----Delete Record");
	out.println("5----Exit");
	
	choice=cin.nextInt();
	switch(choice)
	{
	case 1:{kk();
		break;}
	
	case 2:{System.out.println("Add Details");
	break;}
	case 3:{System.out.println("Add Details");
	break;}
	case 4:{System.out.println("Add Details");
	break;}
	case 5:{System.exit(0);
	break;}
	default:{System.out.println("Enter proper option");
	break;}
	}
	
}
	}
	
	public static void kk() throws ItemException{
		System.out.println("Enter Number of Items to be Added");
		//System.out.println("Add Details")
		int Num_Items;
		Num_Items=cin.nextInt();
		
		while(Num_Items!=0)
		{
			System.out.println("Enter Item ID");
			String item_id=cin.next();
			if(!Validator.validate_id(item_id)) 
			{
				System.exit(0);
			}
			System.out.println("Enter Item Name");
			String item_name=cin.next();
			if(!Validator.validate_name(item_name))
			{
				System.exit(0);
			}
			System.out.println("Enter Item Price");
			double item_price=cin.nextDouble();
			if(!Validator.validate_price(item_price))
			{
				System.exit(0);
			}
			

			Random randomGenerator = new Random();
			int txn_id = randomGenerator.nextInt(9999);
			int id=Integer.parseInt(item_id);
			ItemSchema sch=new ItemSchema(id,item_name,item_price,txn_id);
			Collector.adddetails(sch);
			Num_Items--;
		}
		
		
	}

	

}

