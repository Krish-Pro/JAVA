package com.capgemini.collection;
import java.util.*;
import com.capgemini.bin.*;
	public class Collector{


		static{
			List<ItemSchema> list = new ArrayList<ItemSchema>();
			ItemSchema obj1=new ItemSchema(15,"Park Avenue Soap",24.00,9878);
			list.add(obj1);
			ItemSchema obj2=new ItemSchema(16,"Dove Soap",99.00,987);
			list.add(obj2);
			ItemSchema obj3=new ItemSchema(17,"Pears Soap",60.00,98);
			list.add(obj3);
		}
		
		public static void adddetails(ItemSchema obj)
		{
			List<ItemSchema> list = new ArrayList<ItemSchema>();
			list.add(obj);
		}
		
	}
	
	

