package com.dthoperator.exception;

public class RechargeException extends Exception{
	
	public RechargeException(String name)
	{
		System.out.println("Failed to Recharge.");
		return;
	}

}
