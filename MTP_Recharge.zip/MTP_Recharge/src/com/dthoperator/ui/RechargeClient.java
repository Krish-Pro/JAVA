package com.dthoperator.ui;

import java.util.*;

import com.dthoperator.bean.*;
import com.dthoperator.service.*;
import com.dthoperator.exception.*;


class RechargeClient
{
	static Scanner cin=new Scanner(System.in);
	public static void main(String[] args) throws RechargeException
	{
		 int choice;
		 while(true)
		 {
		 	System.out.println("Enter your choice");
		 	System.out.println("1. Make a Recharge");
		 	System.out.println("2. Display Recharge Details");
		 	System.out.println("3. Exit");

		 	choice=cin.nextInt();
		 	switch(choice)
		 	{
		 	case 1:{
		 		System.out.println("1. Make a Recharge");
		 		recharge();
		 		break;}
		 	
		 	case 2:{System.out.println("2. Display Recharge Details");
		 	System.out.println("Enter Transaction ID");
		 	int txn_id=cin.nextInt();
		 	RechargeCollectionHelper.displayRechargeDetails(txn_id);
		 		
		 		break;}

		 	case 3:{System.exit(0);
		 		break;}
		 	
		 	default:{System.out.println("Enter proper option");
		 		break;}
		 	}
		 }//while
	}

	
	
	
	public static void recharge() throws RechargeException{
		
		System.out.println("Enter the Recharge Details for Home DTH");
		int Num_Items=2;
		//Num_Items=cin.nextInt();
		while(Num_Items!=0)
		{
			
			System.out.println("Select DTH Operator (Airtel / DishTV / Reliance / TATASky");
			String dth_operator=cin.next();
			try {
			if(!RechargeDataValidator.validatedthOperator(dth_operator)) 
			{
				System.exit(0);
			}
			
			System.out.println("Enter Registered Consumer No.");
			String consumer_id=cin.next();
			if(!RechargeDataValidator.validateConsumerNo(consumer_id)) 
			{
				System.exit(0);
			}
			
			System.out.println("Select Plan(Monthly / Quaterly / Half yearly / Annual)");
			String consumer_plan=cin.next();

			if(!RechargeDataValidator.validatePlan(consumer_plan)) 
			{
				System.exit(0);
			}
			
			System.out.println("Enter Amount (Rs.)");
			String recharge_amount=cin.next();

			if(!RechargeDataValidator.validateAmount(recharge_amount)) 
			{
				System.exit(0);
			}

			

			//double c_id=Double.parseDouble(consumer_id);
			int amt=Integer.parseInt(recharge_amount);
			Random randomGenerator = new Random();
			int transaction_id = randomGenerator.nextInt(9999);
			
			RechargeDetails obj=new RechargeDetails(dth_operator,consumer_id,consumer_plan,amt,transaction_id);
			RechargeCollectionHelper.addRechargeDetails(obj);
			}
			
			catch(RechargeException e)
			{
				
				
			}
			Num_Items--;
			if(Num_Items==1)
			System.out.println("Enter the Recharge Details for Office DTH");
			
		}	//while
		
		}//recharge
	
	}//clkass

