package com.dthoperator.service;

import java.util.*;

import com.dthoperator.bean.*;



public class RechargeCollectionHelper
{
	static List<RechargeDetails> list = new ArrayList<RechargeDetails>();
	static{
		
		RechargeDetails obj1=new RechargeDetails("Airtel","1089343431","Monthly",210,4567);
		list.add(obj1);
		RechargeDetails obj2=new RechargeDetails("DishTV","3033221223","Yearly",1260,2345);
		list.add(obj2);
		RechargeDetails obj3=new RechargeDetails("Reliance","8923434300","Quaterly",650,1234);
		list.add(obj3);
	}


	public static void addRechargeDetails(RechargeDetails rechargeDetails)
	{
		list.add(rechargeDetails);
	}

	public static void displayRechargeDetails(int transactionID1)
	{
		for(Object object: list)
		{
			RechargeDetails obj=(RechargeDetails)object;
			if(obj.transactionID==transactionID1)
			{
				System.out.println(object);
			}
		}
	}

}