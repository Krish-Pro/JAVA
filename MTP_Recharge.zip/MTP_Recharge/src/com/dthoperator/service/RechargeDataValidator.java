package com.dthoperator.service;

import java.util.regex.*;

import com.dthoperator.exception.*;

public class RechargeDataValidator
{
	public static boolean validatedthOperator(String dthOperator) throws RechargeException
	{
		if(dthOperator.toLowerCase().equals("airtel")||dthOperator.toLowerCase().equals("dishtv")||dthOperator.toLowerCase().equals("reliance")||dthOperator.toLowerCase().equals("tatasky"))
		{
			return true;
		}
		else 
		{
			throw new RechargeException("A");
			//return false;
		}
	}
	
	public static boolean validateConsumerNo(String consumerNo) throws RechargeException
	{
		String pattern = "[0-9]{10}";
		if(Pattern.matches(pattern,consumerNo))
		{
			return true;
		}
		else
		{
			throw new RechargeException("A");
			//return false;
		}
	}
	
	public static boolean validatePlan(String plan) throws RechargeException
	{
		if(plan.toLowerCase().equals("monthly")||plan.toLowerCase().equals("quaterly")||plan.toLowerCase().equals("half yearly")||plan.toLowerCase().equals("annual"))
		{
			return true;
		}
		else 
		{
			throw new RechargeException("A");
			//return false;
		}
	}
	
	public static boolean validateAmount(String amount) throws RechargeException
	{
		String pattern = "[1-9]{1}[0-9]{2,3}";
		if(Pattern.matches(pattern,amount))
		{
			return true;
		}
		else
		{
			throw new RechargeException("A");
			//return false;
		}
	}
}