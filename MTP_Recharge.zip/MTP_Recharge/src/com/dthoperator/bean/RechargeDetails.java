package com.dthoperator.bean;

public class RechargeDetails
{
	String dthOperator;
	String consumerNo;
	String rechargePlan;
	int amount;
	public int transactionID;
	
	public RechargeDetails(String dthOperator,String consumerNo,String rechargePlan,int amount,int transactionID)
	{
		this.dthOperator=dthOperator;
		this.consumerNo=consumerNo;
		this.rechargePlan=rechargePlan;
		this.amount=amount;
		this.transactionID=transactionID;
	}
	

	public String toString()
	{
		return "DthOperator: "+ dthOperator+ ",Consumer Number: "+consumerNo+",Recharge Plan: "+rechargePlan+",Amount: " +amount+",Transaction ID: " +transactionID;
	}

/*	 public static void main(String args[]) {
	RechargeDetails object = new RechargeDetails("Airtel", 12345,"Monthly",3500,2345);
	System.out.println(object);  
	 }
*/

}